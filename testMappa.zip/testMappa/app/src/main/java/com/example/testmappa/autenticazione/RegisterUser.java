package com.example.testmappa.autenticazione;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.testmappa.R;

import io.realm.Realm;
import io.realm.mongodb.App;
import io.realm.mongodb.AppConfiguration;

import static com.example.testmappa.autenticazione.LoginActivity.app;

public class RegisterUser extends AppCompatActivity {

    private EditText nameView;
    private EditText emailView;
    private EditText passwordView;
    private EditText confirmPasswordView;
    private Button registerBtn;
    private TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nameView = (EditText) findViewById(R.id.name);
        emailView = (EditText) findViewById(R.id.newemail);
        passwordView = (EditText) findViewById(R.id.newpassword);
        confirmPasswordView = (EditText) findViewById(R.id.conpassword);
        registerBtn = (Button) findViewById(R.id.registerbtn);
        loginLink = (TextView) findViewById(R.id.loginlink);

        emailView.setError(null);
        passwordView.setError(null);
        confirmPasswordView.setError(null);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getRegister();
            }
        });

        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterUser.this, LoginActivity.class));
            }
        });
    }

    private void getRegister() {
        final String name = nameView.getText().toString();
        final String email = emailView.getText().toString();
        String password = passwordView.getText().toString();
        String conpassword = confirmPasswordView.getText().toString();
        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Campo richiesto!", Toast.LENGTH_SHORT).show();
            //emailView.setError(getString(R.string.error_field_required));
            focusView = emailView;
            cancel = true;
        } else if (!MiscFunc.isEmailValid(email)) {
            Toast.makeText(this, "e-mail non valida!", Toast.LENGTH_SHORT).show();
            //emailView.setError(getString(R.string.error_invalid_email));
            focusView = emailView;
            cancel = true;
        }

        if (!TextUtils.isEmpty(password) && !MiscFunc.isPasswordValid(password)) {
            Toast.makeText(this, "Password non valida!", Toast.LENGTH_SHORT).show();
            //passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        if (!password.equals(conpassword)) {
            Toast.makeText(this, "Le password non coincidono!", Toast.LENGTH_SHORT).show();
            //confirmPasswordView.setError(getString(R.string.error_incorrect_password));
            focusView = confirmPasswordView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            String appID = "application-0-buyoh";
            Realm.init(this);
            app = new App(new AppConfiguration.Builder(appID)
                    .build());
            app.getEmailPassword().registerUserAsync(email, password, it  -> {
                if (it.isSuccess()) {
                    Log.i("EXAMPLE", "Successfully registered user.");
                } else {
                    Log.e("EXAMPLE", "Failed to register user: " + it.getError().getErrorMessage());
                }
            });
        }
    }
}