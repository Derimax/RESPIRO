package com.example.testmappa.HomeDati;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.SeekBar;
import android.widget.Toast;

import com.example.testmappa.R;
import com.example.testmappa.autenticazione.LoginActivity;
import com.example.testmappa.eventi.EventiActivity;
import com.example.testmappa.info.InfoActivity;
import com.example.testmappa.profilo.ProfiloActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.j256.ormlite.stmt.query.In;
import com.marcinmoskala.arcseekbar.ArcSeekBar;

public class HomeActivity extends AppCompatActivity{

    ArcSeekBar arcSeekBar;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        arcSeekBar = findViewById(R.id.seekArc);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.datiMenu);

        int[] intArray = getResources().getIntArray(R.array.progressGradientColors);
        arcSeekBar.setProgressGradient(intArray);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.datiMenu:

                        return true;

                    case R.id.profiloMenu:
                        startActivity(new Intent(getApplicationContext(),ProfiloActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.eventiMenu:
                        startActivity(new Intent(getApplicationContext(),EventiActivity.class));
                        overridePendingTransition(0,0);

                        return true;

                    case R.id.infoMenu:
                        startActivity(new Intent(getApplicationContext(),InfoActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                    default:
                        return false;
                }
            }
        });

    }


/*


    }*/
}