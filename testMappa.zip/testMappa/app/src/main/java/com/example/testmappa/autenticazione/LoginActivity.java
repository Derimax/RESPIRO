package com.example.testmappa.autenticazione;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;

import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.testmappa.R;
import com.example.testmappa.RilevamentoActivity;

import java.util.concurrent.atomic.AtomicReference;

import io.realm.Realm;
import io.realm.mongodb.App;
import io.realm.mongodb.AppConfiguration;
import io.realm.mongodb.Credentials;
import io.realm.mongodb.User;

public class LoginActivity extends AppCompatActivity {


    private EditText emailView;
    private EditText passwordView;
    private Button signInBtn;
    private TextView registerLink;
    private TextView resetPassword;
    public static App app;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailView = findViewById(R.id.username);
        passwordView = findViewById(R.id.password);
        signInBtn = findViewById(R.id.signinbtn);
        registerLink = findViewById(R.id.registerlink);
        resetPassword = findViewById(R.id.resetpassword);
        emailView.setError(null);
        passwordView.setError(null);

        passwordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        signInBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recoverPassword();
            }
        });

        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegisterUser.class));
            }
        });

    }

    private void attemptLogin() {
        final String email = emailView.getText().toString();
        String password = passwordView.getText().toString();
        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Campo richiesto!", Toast.LENGTH_SHORT).show();
            //emailView.setError(getString(R.string.error_field_required));
            focusView = emailView;
            cancel = true;
        } else if (!MiscFunc.isEmailValid(email)) {
            Toast.makeText(this, "e-mail non valida!", Toast.LENGTH_SHORT).show();
            //emailView.setError(getString(R.string.error_invalid_email));
            focusView = emailView;
            cancel = true;
        }

        if (!TextUtils.isEmpty(password) && !MiscFunc.isPasswordValid(password)) {
            Toast.makeText(this, "Password non valida!", Toast.LENGTH_SHORT).show();
            //passwordView.setError(getString(R.string.error_invalid_password));
            focusView = passwordView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            //UserPasswordCredential credential = new UserPasswordCredential(params[0], params[1]);
            String appID = "application-0-buyoh";
            Realm.init(this);
            app = new App(new AppConfiguration.Builder(appID)
                    .build());

            Credentials emailPasswordCredentials = Credentials.emailPassword(email, password);
            AtomicReference<User> user = new AtomicReference<>();

            app.loginAsync(emailPasswordCredentials, it -> {
                if (it.isSuccess()) {
                    Log.v("AUTH", "Successfully authenticated using an email and password.");
                    user.set(app.currentUser());
                    startActivity(new Intent(LoginActivity.this, RilevamentoActivity.class));
                } else {
                    Toast.makeText(this, "email o password errate, Riprova", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    private void recoverPassword() {
        String email = emailView.getText().toString();
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Per resettare la password, inserisci la mail nel campo.", Toast.LENGTH_SHORT).show();
            //emailView.setError(getString(R.string.error_field_required));
        } else {
            app.getEmailPassword().sendResetPasswordEmailAsync(email, it -> {
                if (it.isSuccess()) {
                    Log.i("EXAMPLE", "Successfully sent the user a reset password link to " + email);
                } else {
                    Log.e("EXAMPLE", "Failed to send the user a reset password link to " + email + ": " + it.getError().getErrorMessage());
                }
            });
        }
    }


}
