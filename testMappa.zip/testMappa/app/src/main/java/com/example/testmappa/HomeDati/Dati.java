package com.example.testmappa.HomeDati;

import io.realm.RealmObject;

//per aggiungereun oggetto in uno schema Realm, questo deve estendere RealmObject.

public class Dati extends RealmObject {


    public Dati(String nomeCittà, String ultimoAggiornamento, int qualitàMediaAria, int Pm25, int Pm10,int No2, int o3, int so2) {
        this.nomeCittà = nomeCittà;
        this.ultimoAggiornamento = ultimoAggiornamento;
        this.qualitàMediaAria = qualitàMediaAria;
        this.Pm25 = Pm25;
        this.Pm10 = Pm10;
        this.No2 = No2;
        this.o3 = o3;
        this.so2 = so2;

    }

    //Le sottoclassi RealmObject devono fornire un costruttore vuoto.
    public Dati () {};

    public String getNomeCittà() {
        return nomeCittà;
    }

    public void setNomeCittà(String nomeCittà) {
        this.nomeCittà = nomeCittà;
    }

    public String getUltimoAggiornamento() {
        return ultimoAggiornamento;
    }

    public void setUltimoAggiornamento(String ultimoAggiornamento) {
        this.ultimoAggiornamento = ultimoAggiornamento;
    }

    public int getQualitàMediaAria() {
        return qualitàMediaAria;
    }

    public void setQualitàMediaAria(int qualitàMediaAria) {
        this.qualitàMediaAria = qualitàMediaAria;
    }

    public int getPm25() {
        return Pm25;
    }

    public void setPm25(int pm25) {
        Pm25 = pm25;
    }

    public int getPm10() {
        return Pm10;
    }

    public void setPm10(int pm10) {
        Pm10 = pm10;
    }

    public int getNo2() {
        return No2;
    }

    public void setNo2(int no2) {
        No2 = no2;
    }

    public int getO3() {
        return o3;
    }

    public void setO3(int o3) {
        this.o3 = o3;
    }

    public int getSo2() {
        return so2;
    }

    public void setSo2(int so2) {
        this.so2 = so2;
    }

    @Override
    public String toString() {
        return "Dati{" +
                "nomeCittà='" + nomeCittà + '\'' +
                ", ultimoAggiornamento='" + ultimoAggiornamento + '\'' +
                ", qualitàMediaAria=" + qualitàMediaAria +
                ", Pm25=" + Pm25 +
                ", Pm10=" + Pm10 +
                ", No2=" + No2 +
                ", o3=" + o3 +
                ", so2=" + so2 +
                '}';
    }

    private String nomeCittà;
    private String ultimoAggiornamento;
    private int qualitàMediaAria;
    private int Pm25;
    private int Pm10;
    private int No2;
    private int o3;
    private int so2;


}
