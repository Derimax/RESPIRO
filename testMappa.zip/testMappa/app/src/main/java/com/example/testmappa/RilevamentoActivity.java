package com.example.testmappa;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.testmappa.HomeDati.HomeActivity;

import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay;

import java.util.ArrayList;
import java.util.List;

public class RilevamentoActivity extends AppCompatActivity {
    private final int REQUEST_PERMISSIONS_REQUEST_CODE = 1;



    private MapView map = null;
    private Button inizia;
    private Button gps;
    private Button ferma;
    private TextView kmpercorsi;
    private TextView punteggio;
    private RotationGestureOverlay mRotationGestureOverlay;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private AlertDialog.Builder adBuilder;
    private AlertDialog dialog;
    private double distanzaPercorsa;
    private double punti;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //handle permissions first, before map is created. not depicted here

        //load/initialize the osmdroid configuration, this can be done
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));
        //setting this before the layout is inflated is a good idea
        //it 'should' ensure that the map has a writable location for the map cache, even without permissions
        //if no tiles are displayed, you can try overriding the cache path using Configuration.getInstance().setCachePath
        //see also StorageUtils
        //note, the load method also sets the HTTP User Agent to your application's package name, abusing osm's
        //tile servers will get you banned based on this string

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        //inflate and create the map
        setContentView(R.layout.activity_rilevamento);

        gps = findViewById(R.id.button);
        inizia = findViewById(R.id.iniziabtn);
        ferma = findViewById(R.id.ferma);
        punteggio = findViewById(R.id.punteggio);
        kmpercorsi = findViewById(R.id.kmpercorsi);
        map = findViewById(R.id.map);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);

        ferma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });

        //per zoomare in una posizione
        IMapController mapController = map.getController();
        mapController.setZoom(15.5);
        GeoPoint startPoint = new GeoPoint(40.923, 14.5338);
        mapController.setCenter(startPoint);

        //per ruotare con due dita
        mRotationGestureOverlay = new RotationGestureOverlay(map);
        mRotationGestureOverlay.setEnabled(true);
        map.setMultiTouchControls(true);
        map.getOverlays().add(this.mRotationGestureOverlay);

        /*per mettere un marker
        Marker startMarker = new Marker(map);
        startMarker.setPosition(startPoint);
        startMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER);
        map.getOverlays().add(startMarker);
        startMarker.setIcon(getResources().getDrawable(R.drawable.rec)); */

        //per ottenere la posizione tramite GPS
        List<GeoPoint> geoPoints = new ArrayList<>();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {


                    Polyline line = new Polyline();
                    line.getOutlinePaint().setColor(Color.BLUE);
                    Log.v("Debug", "sto per aggiungere un punto");
                    GeoPoint point = new GeoPoint(location.getLatitude(), location.getLongitude());
                    mapController.animateTo(point);
                    mapController.setZoom(18.5);
                    geoPoints.add(point);
                    // Log.v("Debug","numero di punti: "+geoPoints.size());
                    // Log.v("Debug", "aggiunto un punto");
                    // Log.v("Debug", "creata una linea");
                    line.setPoints(geoPoints);
                    Log.v("Debug", "creata una linea lunga: "+line.getDistance());
                    map.getOverlayManager().add(line);
                    //Log.v("Debug", "disegnata una linea");
                    map.invalidate();

                    /* NON FUNZIONA
                     (ferma.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            locationManager.removeUpdates(locationListener);
                            distanzaPercorsa = line.getDistance();
                            punti = distanzaPercorsa*10;
                            adBuilder = new AlertDialog.Builder(MainActivity.this);
                            final View distanzapercorsaView = getLayoutInflater().inflate(R.layout.popup,null);
                            punteggio.setText("punti: "+punti);
                            kmpercorsi.setText("km percorsi: "+distanzaPercorsa);
                        }
                    });*/


                /*
                List<GeoPoint> geoPoints = new ArrayList<>();
                GeoPoint point = new GeoPoint(location.getLatitude(), location.getLongitude());
                geoPoints.add(point);
                Polyline line = new Polyline();
                line.setPoints(geoPoints);
                map.getOverlayManager().add(line);
                map.invalidate();*/
            }

            @Override
            public void onProviderDisabled(String s) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        };

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[] {
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET
                },10);
            }
            return;
        } else {
            configureButton();
        }


        /*COME INSERIRE UNA POLYLINE
        List<GeoPoint> geoPoints = new ArrayList<>();

        GeoPoint point = new GeoPoint(45.923, 14.5338);
        GeoPoint point2 = new GeoPoint(46.923, 13.5338);
        GeoPoint point3 = new GeoPoint(47.923, 11.5338);

        geoPoints.add(point);
        geoPoints.add(point2);
        geoPoints.add(point3);

        Polyline line = new Polyline();
        line.setPoints(geoPoints);
        map.getOverlayManager().add(line);
        map.invalidate();*/


        requestPermissionsIfNecessary(new String[]{
                // if you need to show the current location, uncomment the line below
                // Manifest.permission.ACCESS_FINE_LOCATION,
                // WRITE_EXTERNAL_STORAGE is required in order to show the map
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        });
    }

    private void configureButton() {
        gps.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View view) {
                locationManager.requestLocationUpdates("gps",
                        500,
                        0,
                        locationListener);
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this));
        map.onResume(); //needed for compass, my location overlays, v6.0.0 and up
    }

    @Override
    public void onPause() {
        super.onPause();
        //this will refresh the osmdroid configuration on resuming.
        //if you make changes to the configuration, use
        //SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        //Configuration.getInstance().save(this, prefs);
        map.onPause();  //needed for compass, my location overlays, v6.0.0 and up
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (int i = 0; i < grantResults.length; i++) {
            permissionsToRequest.add(permissions[i]);
        }
        if (permissionsToRequest.size() > 0) {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
        switch (requestCode) {
            case 10:
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    configureButton();
                return;
        }
    }

    private void requestPermissionsIfNecessary(String[] permissions) {
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission is not granted
                permissionsToRequest.add(permission);
            }
        }
        if (permissionsToRequest.size() > 0) {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }


    public void iniziaMonitoraggio(View view) {
        inizia.setText("Termina");
        IMapController mapController = map.getController();
        mapController.zoomIn();
    }
}